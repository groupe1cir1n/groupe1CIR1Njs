import * as projets from './projetsFunc.js';

function main(){
    projets.returnToTopButton();
    projets.changeImageUnderMouse();
}

main();